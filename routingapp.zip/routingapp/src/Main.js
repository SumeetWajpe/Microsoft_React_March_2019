import {BrowserRouter,Route,Link} from 'react-router-dom';
import React from 'react';
import { HomePage } from './Home';
import { PostsPage } from './Posts';
import { PostDetailsPage } from './PostDetailsPage';
import { CompWithProps } from './CompWithProps';

export var MainPage = ()=>(
    <div className="container">
        <Link to="/"> Home</Link> | 
        <Link to="/posts"> Posts</Link>   |
        <Link to="/posts/10"> Posts with ID 10</Link> |
        <Link to="/compwithprops"> Comp With Props</Link>           


                <Route path="/" exact component={HomePage}/>
                <Route path="/posts" exact component={PostsPage} />  
                <Route path="/posts/:postid" exact component={PostDetailsPage} />
                <Route 
                path="/compwithprops" 
                exact 
                render={(props)=> <CompWithProps message={'This is passed using render'} {...props} />} />

            
    </div>
)

export var RouterApp = ()=> (
    <BrowserRouter>
                <MainPage/>
    </BrowserRouter>
)