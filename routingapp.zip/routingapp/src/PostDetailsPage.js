import React from 'react';


export var PostDetailsPage = (props) =>{

    var {match:{params}} = props;
    // props.match.params.postid
    console.log(props);

   return <div className="jumbotron">
    <h1> Posts Details for {params.postid} !</h1>
</div>
}
   
