import React from 'react';


export var PostsPage = () =>(
    <div className="jumbotron">
            <h1> Posts !</h1>
    </div>
)