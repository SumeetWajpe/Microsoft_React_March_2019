import React from 'react';


export var HomePage = () =>(
    <div className="jumbotron">
            <h1> Home !</h1>
    </div>
)