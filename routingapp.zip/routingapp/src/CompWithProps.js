import React from 'react';


export var CompWithProps = (props) =>{
    console.log(props);
    return <div className="jumbotron">
            <h1> {props.message}</h1>
    </div>
}
   
