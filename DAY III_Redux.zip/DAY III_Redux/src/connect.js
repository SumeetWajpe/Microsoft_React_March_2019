
import {connect} from 'react-redux';
import App from './App';
import { bindActionCreators } from 'redux';
import * as allactions from './actions/actionCreators';

/* Exposes store data as props to Container component */
function mapStateToProps(storefromprovider){
        return {
            allusers:storefromprovider.users,
            allposts:storefromprovider.posts
        }
}

/* Exposes actionCreators as props */
function mapDispatchToProps(dispatcher){
           return bindActionCreators(allactions,dispatcher);
}

// Higher Order Component !
export var Main = connect(mapStateToProps,mapDispatchToProps)(App)