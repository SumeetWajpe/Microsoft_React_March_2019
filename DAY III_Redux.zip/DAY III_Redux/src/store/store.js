import {createStore} from 'redux';
import { rootReducer } from '../reducers/rootReducer';
import { defaultUsersData } from './data';


// createStore(reducer,storeData)  -> redux !

var storeData = {
    users:defaultUsersData,
    posts:[{id:'1',title:'First Post !'}]
}

export var store = createStore(rootReducer,storeData);