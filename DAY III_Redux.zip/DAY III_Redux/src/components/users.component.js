import React from 'react';
import { UserThumbnail } from './userthumbnail';

export class Users extends React.Component{
    render(){     
    
      var usersToBeCreated = this.props.allusers.map(
        (u,i) => <UserThumbnail 
        key={u.id} 
        theUser={u} 
        {...this.props} 
        index={i} />
      )

      return <div className="container">
                    <div className="row">
                          {usersToBeCreated}
                    </div>
                     
                 </div>
    }
  }