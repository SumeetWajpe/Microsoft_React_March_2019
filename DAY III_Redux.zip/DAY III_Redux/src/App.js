import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Users } from './components/users.component';

// 1. No State !
//2. No Render method !
//3. No lifecyclemethods !
class App extends React.Component{
  render(){
    return <div>
                    <Users {...this.props} />
               </div>
  }
}

export default App;
