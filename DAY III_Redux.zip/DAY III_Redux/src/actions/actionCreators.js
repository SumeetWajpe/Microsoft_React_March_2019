/* Action creators : Return an action ! */

export function DeleteUser(){
    return {type:'DELETE_USER'}
}

export function AddUser(){
    return {type:'ADD_USER'}
}

export function IncrementFollowers(theIndex){
    return { type:'INCREMENT_FOLLOWERS',theIndex}
}

export function DeletePost(){
    return { type:'DELETE_POST'}
}