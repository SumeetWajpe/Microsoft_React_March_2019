import React,{Component} from 'react';
import axios from 'axios';
import {Link} from 'react-router';

export default class Posts extends Component{

    constructor(props){
        super(props);
        this.state = {allposts:[]}
    }
        componentDidMount(){
            // DOM is ready !
         let thePromise =   axios.get('https://jsonplaceholder.typicode.com/posts');
         thePromise.then(
             (response)=>  this.setState({allposts: response.data}),
             (err)=> console.log(err)
         )
        }
        render(){
            let postsToBeCreated =this.state.allposts.map(p=>
            <li key={p.id}><Link to={"/posts/" + p.id}>{p.title}</Link></li>)
            return <div>
                            <h1> All Posts</h1>
                            <ul>
                                {postsToBeCreated}
                            </ul>
                        </div>
        }
}