// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';

import Course from './course.component';// alias
import ListOfCoursesComponent from './listofcourses.component';
import ListOfButtonsComponent from './listofbuttons.component';
import LifeCycleComponent from './lifecycle.component';
import Posts from './posts.component';
import { MainComponent } from './main.component';
import PostDetails from './post.details.compoent';

var allCourses = [{id:1,name: "React",duration:'3 Days'},
{id:2,name: "Angular",duration:'5 Days'},
{id:3,name: "Node",duration:'3 Days'},
{id:4,name: "Python",duration:'2 Days'}
]

// ReactDOM.render(<ListOfCoursesComponent  allcourses={allCourses} />,document.getElementById('content'));
//  ReactDOM.render(<ListOfButtonsComponent   />,document.getElementById('content'));
//   ReactDOM.render(<LifeCycleComponent   />,document.getElementById('content'));


var router = <Router history={browserHistory}>
                        <Route path="/" component={MainComponent}>
                                <IndexRoute component={Posts} />
                                <Route path="/courses" component={ListOfCoursesComponent}>
                                </Route>
                                <Route path="/buttons" component={ListOfButtonsComponent}>
                                </Route>
                                <Route path="/posts/:id" component={PostDetails}>
                                </Route>
                        </Route>
                    </Router>



  ReactDOM.render(router,document.getElementById('content'));
