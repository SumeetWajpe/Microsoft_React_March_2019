import React from 'react';

export default class CourseComponent extends React.Component{
 
    componentWillUnmount(){
        console.log('Within componentWillUnmount');
    }
    render(){
        return  <div  className="CourseStyle">
                    <button className="btn btn-danger" onClick={this.props.DeleteCourseFromParent.bind(this,this.props.coursedetails.id)}>
                        <span className="glyphicon glyphicon-trash"></span>
                    </button>
                    <h1> {this.props.coursedetails.name} </h1>
                    <b>Duration : {this.props.coursedetails.duration}</b>
                </div> 
    }
}
// export function Add(x,y){
//     return x + y;
// }