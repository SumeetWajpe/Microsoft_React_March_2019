import React from 'react';
import CustomButton from './custombutton.component';

export default class ListOfButtonsComponent extends React.Component{
    
    constructor(props){
        super(props);
        this.state = {buttonlist : [10,20,30,40,50]};
    }
    AddNewButton(){
        // set the new state !
        let theNewValue = +(this.refs.txtInput.value);
        this.setState({buttonlist:[...this.state.buttonlist,theNewValue]})
    }
    DeleteButton(){
        // delete the elmement from the state and update the state !
        let thevalueToBeDeleted = +(this.refs.txtInput.value);

        var newList = this.state.buttonlist.filter(e => e !== thevalueToBeDeleted)
        this.setState({buttonlist:newList});
    }
    render(){
        console.log(this.state.buttonlist);
        let buttonToBeCreated = this.state.buttonlist.map(b => <CustomButton key={b} count={b} />)
        return  <div className="container">
                    Enter a Value : <input ref="txtInput"  type="text" />
                    <input type="button" value="Add" 
                    onClick={this.AddNewButton.bind(this)} 
                    className="btn btn-success" />
                    <input type="button" value="Delete" 
                    onClick={this.DeleteButton.bind(this)} 
                    className="btn btn-danger" />
                    <br/>

                    {buttonToBeCreated}
                </div> 
    }
}