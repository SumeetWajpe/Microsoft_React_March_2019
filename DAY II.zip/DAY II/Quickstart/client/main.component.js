import React,{Component} from 'react';
import {Link} from 'react-router';

export class MainComponent extends Component{
    render(){
        return <div className="container">   
<div className="jumbotron">
            <h1>Using Routing App</h1>
</div>
<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">App</Link>
    </div>
    <ul className="nav navbar-nav">
      <li > <Link to="/">Posts</Link></li>
      <li>  <Link to="/courses">Courses</Link></li>
      <li> <Link to="/buttons">Buttons</Link></li>   
    </ul>
  </div>
</nav>
                    {this.props.children}
        </div>
    }
}