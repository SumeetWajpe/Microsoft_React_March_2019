import React from 'react';
import CourseComponent from './course.component';

export default class ListOfCoursesComponent extends React.Component{
   constructor(props){
       super(props);      
       this.state = {courses : [{id:1,name: "React",duration:'3 Days'},
       {id:2,name: "Angular",duration:'5 Days'},
       {id:3,name: "Node",duration:'3 Days'},
       {id:4,name: "Python",duration:'2 Days'}
       ]};
   }   

   DeleteCourse(theId){
       console.log("Inside Parent's handler !" + theId);
       var newCourses = this.state.courses.filter(c => c.id !== theId);
       this.setState({courses : newCourses });
       /// delete the item from collection ??
   }
  
    render(){
            var coursesToBeCreated = this.state.courses.map(c=><CourseComponent
                DeleteCourseFromParent={this.DeleteCourse.bind(this)} 
                coursedetails={c} key={c.id}/>)

        return <div>
                    {coursesToBeCreated}
        </div>
    }
}