import React from 'react';

export default class LifeCycleComponent extends React.Component{
    
    
    constructor(props){
        super(props);
        this.state = {companyName:''};
        console.log('Constructor ');
    }
    componentWillMount(){
        console.log('Within componentWillMount')
    }
    componentDidMount(){
        console.log('Within componentDidMount')
    }

    OnChangeHandler(evt){
        console.log('Within OnChangeHandler..');
       // this.setState({companyName:this.refs.txtCompany.value})
       this.setState({companyName:evt.target.value});
       console.log(this.state);
    }

    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate');
        if(arguments[1].companyName.length < 10){
            return true;
        }

        return false;
    }

    componentWillUpdate(){
        console.log('Within componentWillUpdate');
    //    console.log(this.state);
    }
    componentDidUpdate(){
        console.log('Within componentDidUpdate');
    }

  
    render(){
        console.log('Within Render..');
    //    console.log(this.state);
        return              <div  >
                                 Enter Company Name :    <input type="text" 
                                    ref="txtCompany"
                                    onChange={this.OnChangeHandler.bind(this)} />
                                    <h1>{this.state.companyName}</h1>
                                 </div> 
    }
}
