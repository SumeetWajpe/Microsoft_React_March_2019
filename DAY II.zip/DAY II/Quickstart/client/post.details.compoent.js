import React from 'react';


export default class PostDetails extends React.Component{
    render(){
        // fetch the id from the url !
        console.log(this.props.params.id);
        return <h1> Post Details for {this.props.params.id} </h1>
    }
}