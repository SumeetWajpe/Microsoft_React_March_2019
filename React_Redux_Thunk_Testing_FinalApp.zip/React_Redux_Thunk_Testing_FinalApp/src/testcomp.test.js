import Enzyme,{shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { TestApp } from './testcomp';
import React from 'react';
import ReactDOM from 'react-dom';

Enzyme.configure({ adapter: new Adapter() });

describe('A testing suite',function(){
    it('should create TestComp instance',function(){
        // instance of Comp
        // access the h1
        // test if h1 innertext == 'Test the component !'
        var instance = shallow(<TestApp />);
        var h1 =  instance.find('h1');        
        expect(h1.text()).toEqual("Test component !");
    })
})