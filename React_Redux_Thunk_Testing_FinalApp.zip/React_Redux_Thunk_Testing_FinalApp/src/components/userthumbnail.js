import React from 'react';
import './userthumbnail.css'
export class UserThumbnail extends React.Component{
    render(){     
      return <div className="col-md-3 column userbox">
      <div>
      <div className="pull-right">
      <button className="btn btn-danger btn-md-xs">
                    <span className="glyphicon glyphicon-trash">                   
                    </span>  
              </button>
      </div>
      </div>
   <img src={this.props.theUser.avatar_url} 
                                  className="img-thumbnail" />    
      
             
        <div className="usertitle">
              <span> {this.props.theUser.type}</span> 
        </div>
        <div>
            <div className="pull-right">
              <button className="btn btn-primary" 
    onClick={this.props.IncrementFollowers.bind(null,this.props.index)} >
                    <span className="glyphicon glyphicon-user">
                    {this.props.theUser.followers}
                        </span>  
              </button>
            </div>
            <div className="usertext"><b>{this.props.theUser.login}</b></div>
        </div>    
      </div>
    }
  }