import React from 'react';


export var TestApp = () =>(
    <h1>Test the component !</h1>
)