export function users(defStore=[],action){
    switch(action.type){
        case 'ADD_USER':
                // change logic !     
                console.log('Within users reducer !');
                console.log(action.type);
                console.log(defStore);                  
                return defStore;  // return changed store data !
        case 'INCREMENT_FOLLOWERS':
                // change logic !     
               return [
                       ...defStore.slice(0,action.theIndex),
                       {...defStore[action.theIndex],
                        followers:defStore[action.theIndex].followers + 1},
                       ...defStore.slice(action.theIndex+1)
               ]; // new Store Data !
        case 'DELETE_USER':
                console.log('within users reducer! ');
                console.log(action.type);
                return defStore;
        case 'FETCH_USERS':
                        console.log('Within FETCH_USERS !')
                        return action.response; // new Store !
        default:
               console.log(action.type);
               console.log(defStore);
                return defStore;
    }
}