import { combineReducers } from "redux";
import {posts} from './posts.reducer';
import {users} from './users.reducer';

export var rootReducer = combineReducers({
    posts,users
});

