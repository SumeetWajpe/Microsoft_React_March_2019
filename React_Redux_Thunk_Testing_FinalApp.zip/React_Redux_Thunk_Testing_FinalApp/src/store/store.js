import {createStore,applyMiddleware,compose } from 'redux';
import { rootReducer } from '../reducers/rootReducer';
import { defaultUsersData } from './data';
import thunk from 'redux-thunk';


// createStore(reducer,storeData)  -> redux !

var storeData = {
    users:defaultUsersData,
    posts:[{id:'1',title:'First Post !'}]
}

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

export var store = createStore(rootReducer,  composeEnhancers(applyMiddleware(thunk)));