/* Action creators : Return an action ! */
import axios from 'axios';

export function DeleteUser(){
    return {type:'DELETE_USER'}
}
// get the data from ajax request !
export function FetchUsers(){
    var promise = axios.get('https://api.myjson.com/bins/wc1iy'); // REST API

    return (dispatch)=>{
        promise.then(
            (response)=>{
                dispatch({type:'FETCH_USERS',response:response.data}); // dispatching the action !
            },
            (err)=>{console.log(err)}
        );  
    } 
}

export function AddUser(){
    return {type:'ADD_USER'}
}

export function IncrementFollowers(theIndex){
    return { type:'INCREMENT_FOLLOWERS',theIndex}
}

export function DeletePost(){
    return { type:'DELETE_POST'}
}